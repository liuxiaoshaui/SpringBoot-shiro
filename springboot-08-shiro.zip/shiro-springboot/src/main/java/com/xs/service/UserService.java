package com.xs.service;

import com.xs.pojo.User;

public interface UserService {
    public User queryUserByName(String username);
}
